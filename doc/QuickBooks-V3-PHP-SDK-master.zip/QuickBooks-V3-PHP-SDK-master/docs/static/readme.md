The static folder for all images
