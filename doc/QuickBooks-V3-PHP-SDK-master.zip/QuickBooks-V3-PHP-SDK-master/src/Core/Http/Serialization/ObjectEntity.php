<?php
namespace QuickBooksOnline\API\Core\Http\Serialization;

/**
 * Represents complex data type (like objects, arrays)
 */
class ObjectEntity extends AbstractEntity
{
}
