<?php

namespace QuickBooksOnline\API\Core\Http;

/**
 * Contains properties about how to sent the request to the ids server like Compression, Serialization etc.
 */
class Request extends RequestResponse
{
}
